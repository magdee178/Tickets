const { CommandInteraction, MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const dataGuild = require("../../models/dataGuild");

module.exports = {
	name: "config",
	description: "تكوين نظام البوت",
	type: 'CHAT_INPUT',
	/**
	 *
	 * @param {import("../..").Bot} client
	 * @param {CommandInteraction} interaction
	 * @param {String[]} args
	 */
	run: async (client, interaction, args) => {
		let transcript_channel, staff_role, staff_mention;
		await interaction.reply({embeds: [
			new MessageEmbed()
				.setTitle("نظام التذاكر \🟠")
				.setDescription("مهلا هذا هو نظام التكوين!\n هنا لديك خيارات لتكوين الروبوت.")
				.addField("Transcript Channel", "قم بتعيين القناة التي سيتم إرسال النص إليها.")
				.addField("Staff Role", "قم بتعيين الدور الذي يمكنه استخدام الروبوت.")
				.addField("Staff Mention", "قم بتعيين الدور الذي يمكن أن يذكره الروبوت في كل مرة يفتح فيها تذكرة")
				.setColor("GREEN")
				.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
		], components: [
			new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setLabel("Transcript Channel")
						.setStyle("PRIMARY")
						.setCustomId("config-transcript-channel"),
					new MessageButton()
						.setLabel("Staff Role")
						.setStyle("PRIMARY")
						.setCustomId("config-staff-role"),
					new MessageButton()
						.setLabel("Staff Mention")
						.setStyle("PRIMARY")
						.setCustomId("config-staff-mention"),
					new MessageButton()
						.setEmoji("👀")
						.setStyle("PRIMARY")
						.setCustomId("config-show"),
					new MessageButton()
						.setEmoji("✖️")
						.setStyle("DANGER")
						.setCustomId("config-cancel")
				)
		], fetchReply: true});

		const collector = interaction.channel.createMessageComponentCollector({
			filter: (m) => m.user.id === interaction.user.id,
			componentType: "BUTTON",
			max: 2
		});

		collector.on("collect", async (int) => {
			await int.deferUpdate();
			const button = int.customId.split("config-")[1];
			if (button === "transcript-channel") {
				interaction.editReply({embeds: [
					new MessageEmbed()
						.setTitle("نظام التذاكر \🟠")
						.setDescription("مرحباً، يرجى ذكر القناة التي سيتم إرسال النص إليها.\n**تذكر** إذا كنت تريد إزالة البيانات التي قمت بتكوينها، فاكتب **remove** وأرسل الرسالة")
						.setColor("ORANGE")
						.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
				], components: [
					new MessageActionRow().addComponents(
						new MessageButton()
							.setEmoji("✖️")
							.setStyle("DANGER")
							.setCustomId("config-cancel")
					)
				]});

				const messageCollector = interaction.channel.createMessageCollector({
					filter: (m) => m.author.id === interaction.user.id,
					max: 1
				});

				messageCollector.on("collect", async (message) => {
					message.delete();
					collector.stop();
					const mentionedChannel = message.mentions.channels.first();
					if (mentionedChannel) {
						transcript_channel = mentionedChannel.id;
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.transcriptChannel = transcript_channel;
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									transcriptChannel: transcript_channel
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("تم تعيين القناة بنجاح!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مهلا، حدث خطأ في إعداد القناة!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else if (message.content === "remove") {
						transcript_channel = "";
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.transcriptChannel = transcript_channel;
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									transcriptChannel: transcript_channel
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("مهلا، تم حذف القناة!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مرحبًا، حدث خطأ أثناء إزالة القناة!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else {
						return interaction.editReply({embeds: [
							new MessageEmbed()
								.setTitle("نظام التذاكر \🔴")
								.setDescription("عليك أن تذكر قناة!")
								.setColor("RED")
								.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
						], components: []});
					}
				});
			} else if (button === "staff-role") {
				interaction.editReply({embeds: [
					new MessageEmbed()
						.setTitle("نظام التذاكر \🟠")
						.setDescription("مرحبًا، يرجى ذكر الدور الذي يمكنه استخدام الروبوت.\n**تذكر** إذا كنت تريد إزالة البيانات التي قمت بتكوينها، فاكتب **remove** وأرسل الرسالة")
						.setColor("ORANGE")
						.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
				], components: [
					new MessageActionRow().addComponents(
						new MessageButton()
							.setEmoji("✖️")
							.setStyle("DANGER")
							.setCustomId("config-cancel")
					)
				]});
				const messageCollector = interaction.channel.createMessageCollector({
					filter: (m) => m.author.id === interaction.user.id,
					max: 1
				});

				messageCollector.on("collect", async (message) => {
					collector.stop();
					message.delete();
					const mentionedRole = message.mentions.roles.first();
					if (mentionedRole) {
						staff_role = mentionedRole.id;
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.staffRole = staff_role;
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									staffRole: staff_role
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("تم تعيين الدور بنجاح!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مرحبًا، حدث خطأ في تحديد الدور!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else if (message.content === "remove") {
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.staffRole = "";
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									staffRole: ""
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("مهلا تمت إزالة دور الموظفين!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مرحبًا، حدث خطأ أثناء إزالة الدور!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else {
						collector.stop();
						return interaction.editReply({embeds: [
							new MessageEmbed()
								.setTitle("نظام التذاكر \🔴")
								.setDescription("عليك أن تذكر الدور!")
								.setColor("RED")
								.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
						], components: []});
					}
				});
			} else if (button === "staff-mention") {
				interaction.editReply({embeds: [
					new MessageEmbed()
						.setTitle("نظام التذاكر \🟠")
						.setDescription("مرحبًا، يرجى ذكر المستخدم الذي يمكنه استخدام الروبوت.\n**تذكر** إذا كنت تريد إزالة البيانات التي قمت بتكوينها، فاكتب **remove** وأرسل الرسالة")
						.setColor("ORANGE")
						.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
				], components: [
					new MessageActionRow().addComponents(
						new MessageButton()
							.setEmoji("✖️")
							.setStyle("DANGER")
							.setCustomId("config-cancel")
					)
				]});
				const messageCollector = interaction.channel.createMessageCollector({
					filter: (m) => m.author.id === interaction.user.id,
					max: 1
				});

				messageCollector.on("collect", async (message) => {
					collector.stop();
					message.delete();
					const mentionedRole = message.mentions.roles.first();
					if (mentionedRole) {
						staff_mention = mentionedRole.id;
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.mentionStaff = staff_mention;
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									mentionStaff: staff_mention
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("مرحبًا، تم تحديد دور منشن الموظفين!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مرحبًا، حدث خطأ في تحديد الدور الذي ذكره طاقم العمل!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else if (message.content === "remove") {
						try {
							const guildData = await dataGuild.findOne({
								guildID: interaction.guild.id
							});
							if (guildData) {
								guildData.mentionStaff = "";
								await guildData.save();
							} else {
								const newGuildData = new dataGuild({
									guildID: interaction.guild.id,
									mentionStaff: ""
								});
								await newGuildData.save();
							}
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \✅")
									.setDescription("مهلا، تمت إزالة منشن الموظفين!")
									.setColor("GREEN")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						} catch (error) {
							interaction.editReply({embeds: [
								new MessageEmbed()
									.setTitle("نظام التذاكر \❌")
									.setDescription("مرحبًا، حدث خطأ أثناء إزالة الدور المذكور في طاقم العمل!\n" + "```" + error + "```")
									.setColor("RED")
									.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
							], components: []});
						}
					} else {
						collector.stop();
						return interaction.editReply({embeds: [
							new MessageEmbed()
								.setTitle("نظام التذاكر \🔴")
								.setDescription("عليك أن تذكر الدور!")
								.setColor("RED")
								.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
						], components: []});
					}
				});
			} else if (button === "cancel") {
				collector.stop();
				return interaction.editReply({embeds: [
					new MessageEmbed()
						.setTitle("نظام التذاكر \🔴")
						.setDescription("لقد ألغيت العملية!")
						.setColor("RED")
						.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
				], components: []});
			} else if (button === "show") {
				collector.stop();
				const guildData = await dataGuild.findOne({
					guildID: interaction.guild.id
				});
				if (!guildData) {
					return interaction.editReply({embeds: [
						new MessageEmbed()
							.setTitle("نظام التذاكر \🔴")
							.setDescription("هذا الخادم لم يقم بتكوين نظام التذاكر!")
							.setColor("RED")
							.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
					], components: []});
				}
				const data = {
					transcript_channel: guildData.transcriptChannel || "لم يتم التعيين!",
					staff_role: guildData.staffRole || "لم يتم التعيين!",
					staff_mention: guildData.mentionStaff || "لم يتم التعيين!",
				}
				return interaction.editReply({embeds: [
					new MessageEmbed()
						.setColor("GREEN")
						.setTitle("نظام التذاكر \✅")
						.setDescription("فيما يلي البيانات التي تم تكوينها حاليًا:")
						.setFooter({text: `${client.user.username}`, iconURL: client.user.displayAvatarURL({dynamic: true})})
						.addFields([
							{
								name: "Transcript Channel 📚",
								value: data.transcript_channel,
								inline: false
							},
							{
								name: "Staff Role 👤",
								value: data.staff_role,
								inline: false
							},
							{
								name: "Staff Mention 🗣️",
								value: data.staff_mention,
								inline: false
							}
						])
				], components: []});
			}
		});
	},
};