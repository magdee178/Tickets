const { CommandInteraction, MessageEmbed } = require("discord.js");

module.exports = {
  name: "ping",
  description: "لمشاهدة بنج البوت ✨",
  run: async (client, interaction, message) => {
    try {
      const embed = new MessageEmbed()
        .setColor("#0099ff")
        .setTitle("Ping")
        .setDescription(`Pong: ${client.ws.ping}ms`)
      interaction.reply({ embeds: [embed], ephemeral: true })
    } catch (err) {
      console.log(err);
    }
  }
}