const { CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, SlashCommandBuilder } = require("discord.js");

module.exports = {
  name: "help",
  description: "مشاهدة جميع أوامر البوت ✨",
  run: async (client, interaction, message) => {
    try {
        let embed = new MessageEmbed()
          .setAuthor({ name: "Help Menu", iconURL: client.user.displayAvatarURL({ dynamic: true }) })
          .setColor("#0099ff")
          .setTitle("الأوامر المتاحة")
          .setDescription("فيما يلي الأوامر المتاحة:")
          .addField("/config", "تكوين نظام البوت")
          .addField("/about", "معلومات عن البوت")
          .addField("/ping", "وقت إستجابة البوت")
          .addField("/add", "إضافة مستخدم للتذكرة")
          .addField("/alert", "تنبيه المستخدم للرد على تذكرته")
          .addField("/claim", "إستلام التذكرة")
          .addField("/close", "إغلاق التذكرة")
          .addField("/open", "فتح التذكرة")
          .addField("/giveto", "إعطاء التذكرة لموظف آخر")
          .addField("/remove", "إزالة مستخدم من قناة التذكرة")
          .addField("/rename", "إعادة تسمية قناة التذكرة")
          .addField("/ticket-manage delete", "حذف لوحة التذاكر")
          .addField("/ticket-manage list", "قائمة بجميع لوحات التذاكر")
          .addField("/ticket-manage send", "إرسال لوحة التذاكر")
          .addField("/ticket-manage setup", "لوحة تذكرة الإعداد")
        .setFooter({ text: `Requested by ${interaction.user.tag}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });
      
        let row = new MessageActionRow()
          .addComponents(
            new MessageButton()
              .setStyle('LINK')
              .setLabel('bio.link')
              .setURL(`https://bio.link/magdee`)
          );

        interaction.reply({ embeds: [embed], components: [row], ephemeral: false });
    } catch (err) {
        console.log(err);
    }
  }
}